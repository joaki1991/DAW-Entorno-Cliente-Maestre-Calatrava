 "use strict";
 
 //Genera el array aleatorio
 function addExample (num) {
 	var str = "";
 	var max = 100;
 	var min = 0;
 	//Bucle que genera una lista de num enteros separados por coma.
 	for (let i=0; i<num-1; i++){ 
 		str = str + Math.floor(Math.random()*(max-min+1)+min) + ", "; //Función que genera un random entre 0 y 100.
 	}
 	str = str + Math.floor(Math.random()*(max-min+1)+min); //No está en el bucle para no concatenar la última coma
 	return str;
 }

 //Función que trabaja con los elementos de la página
 function addElementPage () {
 	var integers = document.getElementById ("array1").value.split(/\,(?:\s)*/); //Array de Strings con los enteros.
 	var resultado = document.getElementById ("resultado"); //Elemetos para mostrar el resultado
 	var position = parseInt (document.getElementById ("numInteger1").value); //Obtenemos la posición donde almacenar el resultado de la página	
 	var number = parseInt (document.getElementById ("element").value); //Obtenemos el número a almacenar de la página	

 	addElementAt (integers, position, number); //Añade el número al array. El array es un objeto se pasa por referencia
 	resultado.innerHTML = integers; //Se muestra el resultado
 }

 //Función independiente de los elementos de la página. Sería reutilizable en culaquier otra página.
 function addElementAt (array, position, number) {
 	for (let i = position, tmp = 0; i< array.length; i++){
		tmp = array[i]; 
		array[i] = number;
		number = tmp;
 	}
 	array[array.length] = number;
 } 