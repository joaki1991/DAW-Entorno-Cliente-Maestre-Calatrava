 "use strict";
 
 //Genera el array aleatorio
 function addExample (num) {
 	var str = "";
 	var max = 100;
 	var min = 0;
 	//Bucle que genera una lista de num enteros separados por coma.
 	for (let i=0; i<num-1; i++){ 
 		str = str + Math.floor(Math.random()*(max-min+1)+min) + ", "; //Función que genera un random entre 0 y 100.
 	}
 	str = str + Math.floor(Math.random()*(max-min+1)+min); //No está en el bucle para no concatenar la última coma
 	return str;
 }


 function validate () {
 	//Arrays de string con number.
 	var integers1 = document.getElementById ("array1").value.split(/\,(?:\s)*/);
 	var integers2 = document.getElementById ("array2").value.split(/\,(?:\s)*/);
 	var resultado = document.getElementById ("resultado"); //Elemento donde se muestra el resultado.
 	var arrayResult=[];

 	resultado.innerHTML = integers1.concat (integers2); //La función concat no hace lo que realmente tiene que hacer el ejercicio

 	var count = 0;
 	var max = Math.max(integers1.length, integers2.length); //Longitud máxima entre los dos arrays. Se guarda en una variable para no estar calculando en cada pasada del bucle
 	for (let i = 0; i< max; i++){
 		if (i < integers1.length) { //Si no es el final de array se añade el elemento
 			arrayResult[count] = integers1[i];
 			count++;	
 		}
 		if (i < integers2.length) { //Si no es el final de array se añade el elemento
 			arrayResult[count] = integers2[i];
 			count++;	
 		} 		 		
 	}
 	//El bucle es claramente ineficiente. Se realiza 2 preguntas por cada iteración del bucle.

 	resultado.innerHTML = arrayResult;
 }