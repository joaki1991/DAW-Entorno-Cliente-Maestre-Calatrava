 "use strict";
 
 //Genera un string con los milisegundos para crear las fechas en forma aleatoria
 function addExample (num) {
 	var str = "";
 	var max = 1006500000000;
 	var min = 86400000;
 	for (var i=0; i<num; i++){
 		str = str + Math.floor(Math.random()*(max-min+1)+min) + ", ";
 	}
 	str = str + Math.floor(Math.random()*(max-min+1)+min);
 	return str; 	
 }

//Función que crea una fecha por cada milisegundo y lo guarda en la posición indicada.
function createDate(element, index, array) {
  array[index] = new Date (parseInt (element));
}


 function sortDates () {
 	var dates = document.getElementById ("dates").value.split(/\,(?:\s)*/); //Array de string con las fechas

 	//Se invocará createDate por cada elemento de dates, pasándole el elemento, el índice y el propio array dates.
 	dates.forEach(createDate);

 	//Ordena el array pasándole la función indicada para comparar los elementos del mismo.
	dates.sort(function(a, b){return a.getTime()-b.getTime()}); 	
	drawArray (dates);
 }

 function sortDatesHourMinutes () {
 	var dates = document.getElementById ("dates").value.split(/\,(?:\s)*/);  //Array de string con las fechas

 	//Se invocará createDate por cada elemento de dates, pasándole el elemento, el índice y el propio array dates.
 	dates.forEach(createDate);

 	//Ordena el array primero tenienedo en cuenta las horas, y si son iguales, se comparan los minutos.
	dates.sort(function(a, b){if (a.getHours() !== b.getHours()){return a.getHours()-b.getHours()}else{return a.getMinutes()-b.getMinutes()}});
	drawArray (dates);
 }

// Recorre el array para mostrarlo
 function drawArray (array){
 	var stackDates = document.getElementById ("stackDates");  	
 	stackDates.innerHTML = "";

	for (let i of array) {
	   stackDates.innerHTML = stackDates.innerHTML + i + "<br/>"
	}
 }