 "use strict";
 
 //Genera el array aleatorio
 function addExample (num) {
 	var str = "";
 	var max = 100;
 	var min = 0;
 	//Bucle que genera una lista de num enteros separados por coma.
 	for (let i=0; i<num-1; i++){ 
 		str = str + Math.floor(Math.random()*(max-min+1)+min) + ", "; //Función que genera un random entre 0 y 100.
 	}
 	str = str + Math.floor(Math.random()*(max-min+1)+min); //No está en el bucle para no concatenar la última coma
 	return str;
 }

 function validate () {
 	//Arrays de string con number.
 	var integers1 = document.getElementById ("array1").value.split(/\,(?:\s)*/);
 	var integers2 = document.getElementById ("array2").value.split(/\,(?:\s)*/);
 	var resultado = document.getElementById ("resultado"); //Elemento donde se muestra el resultado.
 	var arrayResult=[]; 	
 	var aux;
 	var minLength;

 	//Obtengo la longitud mínima de ambos arrays en "minLength", y en aux guardo una referencia del array más largo.
 	if (integers1.length < integers2.length) {
 		aux = integers2;
 		minLength = integers1.length;
 	} else {
 		aux = integers1;
 		minLength = integers2.length;
 	}

 	//Recorro ambos arrays hasta que finaliza el array más corto.
 	var i; //La i está fuera del bucle para reutilizarla.
 	for (i = 0; i<minLength ; i++){
 		arrayResult.push(integers1[i]);
 		arrayResult.push(integers2[i]);
 	}
 	// i=minLength en este momento. Recorro el array más largo, por medio de aux, hasta que finalice.
 	for (;i<aux.length;i++){
 		arrayResult.push(aux[i]);
 	}

 	resultado.innerHTML = arrayResult;
 }