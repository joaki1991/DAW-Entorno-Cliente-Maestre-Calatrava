 "use strict";

//Variable global para contener lso valores de la pila
 var ARRAY = [];

//Limpia el formulario de entrada
 function cleanData (){
 	//document.getElementById ("resultado").innerHTML = "";
 	document.getElementById ("num").value = "" ;  
 }

// Función invocada desde HTML para recoger el número y mostrar el array.
 function pushNumber () {
 	document.getElementById ("resultado").innerHTML = "";
 	var num = parseInt (document.getElementById ('num').value);

 	resultado.innerHTML = "La longitud de la cola es ahora: " + ARRAY.push(num); 	
 	drawStack ();	
 }

//Función que introduce un elemento el primero de la cola
 function unshiftNumber () {
 	document.getElementById ("resultado").innerHTML = "";
 	var num = parseInt (document.getElementById ('num').value);

 	resultado.innerHTML = "La longitud de la cola es ahora: " + ARRAY.unshift(num);
 	drawStack ();	
 }

//Función para eliminar un elemento de la cola.
 function shiftNumber () {
 	var resultado = document.getElementById ("resultado"); 
 	if (ARRAY.length == 0) resultado.innerHTML = "La cola está vacía"; 	
 	else resultado.innerHTML = "Elemento consumigo: " + ARRAY.shift(); 	 	
 	drawStack ();	
 }

// Recorre la pila para mostrarla
 function drawStack (){
 	var stack = document.getElementById ("stack");  	
 	stack.innerHTML = "";

	for (let i of ARRAY) {
	   stack.innerHTML = stack.innerHTML + i + "<br/>"
	}
 }