 "use strict";

//Variable global para contener lso valores de la pila
 var ARRAY = [];

//Limpia el formulario de entrada
 function cleanData (){
 	//document.getElementById ("resultado").innerHTML = "";
 	document.getElementById ("num").value = "" ;  
 }

// Función invocada desde HTML para recoger el número y mostrar el array.
 function pushNumber () {
 	document.getElementById ("resultado").innerHTML = "";
 	var num = parseInt (document.getElementById ('num').value);
 	ARRAY.push(num); 	
 	drawStack ();	
 }

// Función que consume un número y lo muestra en la página
 function popNumber () {
 	var resultado = document.getElementById ("resultado"); 
 	if (ARRAY.length == 0) resultado.innerHTML = "La pila está vacía"; 	
 	else resultado.innerHTML = "Elemento consumigo: " + ARRAY.pop(); 	 	
 	drawStack ();	
 }

// Recorre la pila para mostrarla
 function drawStack (){
 	var stack = document.getElementById ("stack");  	
 	stack.innerHTML = "";

	for (let i of ARRAY) {
	   stack.innerHTML = stack.innerHTML + i + "<br/>"
	}
 }