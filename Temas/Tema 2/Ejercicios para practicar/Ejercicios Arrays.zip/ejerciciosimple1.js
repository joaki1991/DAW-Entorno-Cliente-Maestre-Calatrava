 "use strict";
 
 function addExample () {
 	document.getElementById ("array").value = "32, 34, 12, 5, 7";
 }

 function validate () {
 	//Dado un stirng con enteros separados por comas, obtengo un array utilizando la "," como separador.
 	var integers = document.getElementById ("array").value.split(/\,(?:\s)*/); 
 	var resultado = document.getElementById ("resultado"); //Elemento donde se muestra el resultado
 	//Variables para obtener los resultados. Se le asigna la constante Infinity.
 	var mayor = -Infinity; 
 	var menor = Infinity;
 	var suma = 0;
 	var intTmp = 0; //Variable para calculos temporales.
 	//for (let i=0; i<integers.length; i++){
 	for (let i of integers) { //Bucle for of. El equivalente tradicional está comentado.
 		intTmp = parseInt (i); //Evitamos ejecutar constatemente el parseInt. Recordad que el array es de String.
 		if (intTmp < menor) menor = intTmp;
 		if (intTmp > mayor) mayor = intTmp;

 		suma = suma + intTmp;
 	}

 	resultado.innerHTML = "Mayor: " + mayor + ";<br/>" + 
 						  "Menor: " + menor + ";<br/>" +
 						  "Media: " + suma / integers.length;
 }