 "use strict";
 
 //Genera el array aleatorio
 function addExample (num) {
 	var str = "";
 	var max = 100;
 	var min = 0;
 	//Bucle que genera una lista de num enteros separados por coma.
 	for (let i=0; i<num-1; i++){ 
 		str = str + Math.floor(Math.random()*(max-min+1)+min) + ", "; //Función que genera un random entre 0 y 100.
 	}
 	str = str + Math.floor(Math.random()*(max-min+1)+min); //No está en el bucle para no concatenar la última coma
 	return str;
 }

 function sortArray () {
 	var integers = document.getElementById ("array1").value.split(/\,(?:\s)*/); //array de string con eneteros
 	var resultado = document.getElementById ("resultado"); //Elemento donde se muestra el resultado

 	sort(integers); //Ordenamos el array

 	resultado.innerHTML = integers; //Mostramos el resultado
 }

 //Función de ordanmiento de la burbuja.
 function sort(array){ 	
 	for (let i = 0, tmp; i < array.length-1; i++){ //Bucle que recorre todos los elementos hasta el penúltimo
 		for (let j = i+1; j < array.length; j++){ //Bucle para hacer comparaciones. Se comienza en el siguiente valor de i ya que los anteriores están ya ordenados
	 		if (parseInt (array[i])>parseInt (array[j])) { //Comparativa entre elementos
	 			tmp = array[i];  //Si se cumple la condición se intercambian los valores de las posiciones.
	 			array[i] = array [j];
	 			array [j] = tmp;
	 		}  			
 		}
 	} 	
 }