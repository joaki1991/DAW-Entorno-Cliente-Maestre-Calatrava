 "use strict";
 //Genera el array aleatorio
 function addExample () {
 	var str = "";
 	var max = 100;
 	var min = 0;
 	//Bucle que genera una lista de 5 enteros separados por coma.
 	for (let i=0; i<4; i++){ 
 		str = str + Math.floor(Math.random()*(max-min+1)+min) + ", "; //Función que genera un random entre 0 y 100.
 	}
 	str = str + Math.floor(Math.random()*(max-min+1)+min); //No está en el bucle para no concatenar la última coma
 	return str;
 }

 function validate () {
 	var integers1 = document.getElementById ("array1").value.split(/\,(?:\s)*/); //Array de string con los enteros
 	var integers2 = document.getElementById ("array2").value.split(/\,(?:\s)*/); //Array de string con los enteros
 	var resultado = document.getElementById ("resultado");
 	var arrayResult=[];

 	resultado.innerHTML = integers1.concat (integers2); //La función concat no hace lo que realmente tiene que hacer el ejercicio

 	for (let i = 0; i<integers2.length; i++){ //Bucle para recorrer los enteros
 		arrayResult[i*2] = integers1[i]; //El índice del algoritmo se va actulizando con la variable del bucle.
 		arrayResult[i*2+1] = integers2[i]; //Se simplifica utilizando la función push de array.
 	}

 	resultado.innerHTML = arrayResult;
 }