 "use strict";

 function execExercise (numM,numN) {
 	var pmatriz = document.getElementById ("matriz"); 
 	var pvector = document.getElementById ("Vector"); 
 	var presultado = document.getElementById ("Resultado"); 
 	pmatriz.innerHTML = "";
 	pvector.innerHTML = "";
 	presultado.innerHTML = "";
 	
 	var matrix = new Array (numM);
 	var vector = new Array (numM);
 	for (let i=0;i<numM;i++){ //Recorre la matriz para instanciarla.
 		matrix[i]=[new Array (numN)];
 	}

 	getRandomMatrix (matrix,numM,numN);
 	getRandomArray (vector,numM);
 	drawMatrix (pmatriz, matrix);
 	drawArray (pvector, vector);

 	presultado.innerHTML = "El vector está en la matriz: " + search(matrix, vector);

 }

// Función para mostrar el array
 function drawArray(elem, array){
 	for (let x of array){ 		
		elem.innerHTML = elem.innerHTML + x + " ";
 	}
 }

 //Función para mostrar la matriz.
 function drawMatrix (elem, matrix){
 	elem.innerHTML="";
 	for (let array of matrix) { //En array tendremos cada uno de los array que tenemos en matrix
 		for (let value of array) { //En value obtenemos cada valor de los arrays internos.
 			elem.innerHTML = elem.innerHTML + value + " ";
 		}
 		elem.innerHTML = elem.innerHTML + "<br/>";
 	}
 }

//Función que rellena la matriz con números aleatorios
  function getRandomMatrix (matrix,numM, numN) {
 	var max = 2;
 	var min = 0;
 	for (let i=0,j; i<numM; i++){
 		for (j=0;j<numN;j++){
 			matrix[i][j] = Math.floor(Math.random()*(max-min+1)+min);
 		} 		
 	}
 }

//Función que genera el array con números aleatorios
  function getRandomArray (array,numM) {
 	var max = 2;
 	var min = 0;
 	for (let i=0,j; i<numM; i++){
 		array[i] = Math.floor(Math.random()*(max-min+1)+min);
 	}
 }

//Búsqueda del vector en la matriz
 function search (matrix, vector){
 	var x = 0;
 	var y = 0;
 	var isVector = false;
 	var isValues = true;

 	while (x < matrix[0].length && isVector === false){ //Bucle que recorre todos los arrays de la matriz
 		while (y < vector.length && isValues === true){ //Bucle para comparar cada array con el vector.
	 		if (matrix[y][x] !== vector[y]){ //Si los valores de los índices no coincides, no continuamos comparando.
	 			isValues = false;
	 		} else {
	 			y++;
	 		}			
 		}
 		if (isValues === true){  //Si todos los valores coinciden, cambiamos la variable booleana para salir del bucle principal.
 			isVector = true;
 		} else { //Reiniciamos los valores para seguir buscando.
 			x++;
 			y=0;
 			isValues = true;
 		}
 	}

 	return isVector; //Devolvemos si hemos encontrado el vector o no.
 }