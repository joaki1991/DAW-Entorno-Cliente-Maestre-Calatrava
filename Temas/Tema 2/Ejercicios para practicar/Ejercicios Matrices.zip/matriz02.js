 "use strict";

 function validate () {
 	var resultado = document.getElementById ("resultado"); 
 	var array=[[],[],[],[],[],[],[],[]]; //Array para el tablero

    for (let x=0,y,xy;x<8;x++) {
		for (y=0;y<8;y++) {
			xy = "" + x + y; //Concatenamos los índices x e y para realizar comparaciones a través de un string.
			switch (xy) { 
			    case "10": //Posiciones de los peones
			    case "11":
			    case "12":
			    case "13":
			    case "14":
			    case "15":
			    case "16":
			    case "17":
			    case "60":
			    case "61":
			    case "62":
			    case "63":
			    case "64":
			    case "65":
			    case "66":
			    case "67":			    
			        array [x][y] = "P";
			        break;
			    case "00": //Posiciones de las torres
			    case "70":
			    case "07":
			    case "77":
			        array [x][y] = "T";
			        break;			        
			    case "01": //Posiciones de caballos
			    case "71":
			    case "06":
			    case "76":
			        array [x][y] = "C";
			        break;			        			        
			    case "02": //Posiciones de alfiles
			    case "72":
			    case "05":
			    case "75":
			        array [x][y] = "A";
			        break;			        			        			        
			    case "03"://Posiciones de la reina
			    case "74":
			        array [x][y] = "R";
			        break;			        			        			        
			    case "04"://Posiciones del rey
			    case "73":
			        array [x][y] = "K";
			        break;			        			        			        			        
			    default: //Posiciones por defecto espacios.
			        array [x][y] = "&nbsp;";
			}			
		}
	}

 	drawMatrix (resultado, array);
 }

 //Función para mostrar la matriz.
 function drawMatrix (elem, matrix){
 	for (let array of matrix) { //En array tendremos cada uno de los array que tenemos en matrix
 		for (let value of array) { //En value obtenemos cada valor de los arrays internos.
 			elem.innerHTML = elem.innerHTML + value + " ";
 		}
 		elem.innerHTML = elem.innerHTML + "<br/>";
 	}
 }

 window.onload = validate;