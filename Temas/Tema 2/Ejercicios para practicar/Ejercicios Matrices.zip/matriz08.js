 "use strict";

var matrix; //Variable global con la matriz
//Índices de la última posición de la matriz
var xMatrix = 0; 
var yMatrix = 0;

//Función para fijar dimensión de la matriz
function setDim (numN) {
 	var bSetDim = document.getElementById ("bSetDim"); 
 	var numberN = document.getElementById ("numberN"); 
 	var bPushStack = document.getElementById ("bPushStack"); 
 	var bPopStack = document.getElementById ("bPopStack"); 

 	//Deshabilitamos los botones de fijar dimensión
 	bSetDim.disabled = true;
 	numberN.disabled = true;

 	//Habilitamos los botones para apilar y desapilar.
 	bPushStack.disabled = false;
 	bPopStack.disabled = false;
 	
 	//Instanciamos las matrices.
 	matrix = new Array (numN);
 	for (var i=0;i<numN;i++){
 		matrix[i]=[new Array (numN)];
 	}
 }

//Función para obtener enteros aleatoriamente.
function getRandomNumber () {
 	var max = 9;
 	var min = 0;
 	return Math.floor(Math.random()*(max-min+1)+min);
}

//Devuelve si la matriz es vacía
function isEmptyMatrix(){
	if (xMatrix === 0 && yMatrix === 0){
		return true;
	} else {
		return false;
	}
}

//Devuelve si la matriz está completa
function isFullMatrix(){
	if (yMatrix === matrix.length){
		return true;
	} else {
		return false;
	}
}

//Función para obtener el siguiente índice.
function nextIndex (){	
	xMatrix++;
	if (xMatrix === matrix.length){ //Si llegamos al final de la fila, comenzamos una nueva
		xMatrix = 0;
		yMatrix++;
	}
}

//Función para obtener el índice previo 
function previousIndex (){	
	if (xMatrix === 0){ //Si es el inicio de fila, volvemos a una fila anterior.
		xMatrix = matrix.length-1;
		yMatrix--;
	} else {
		xMatrix--;
	}
}

//Función para apilar un number de forma aleatoria
function pushStack () {
	document.getElementById ("Resultado").innerHTML = "";
	if (!isFullMatrix ()){ //Apilarmos si no está completa.
		matrix[xMatrix][yMatrix] = getRandomNumber (); //Obtenemos número aleatorio para apilar
		console.log ("push: " + xMatrix + " " + yMatrix + ": " + matrix[xMatrix][yMatrix]);
		nextIndex (); //Obtenemos nuevo índice.
		drawMatrix (document.getElementById ("matriz"), matrix);		
		console.log ("nextIndex: " + xMatrix + " " + yMatrix);		
	} else {
		document.getElementById ("Resultado").innerHTML = "No puedo añadir más elementos.";
	}
}

//Función para desapilar un number de la pila.
function popStack () {
	document.getElementById ("Resultado").innerHTML = "";
	if (!isEmptyMatrix ()){ //Desapilamos si no está vacía.
		matrix[xMatrix][yMatrix] = ""; //Dejamos un vacío en la matriz.
		console.log ("pop: " + xMatrix + " " + yMatrix + ": " + matrix[xMatrix][yMatrix]);
		previousIndex (); //Recuperamos el índice anterior.
		drawMatrix (document.getElementById ("matriz"), matrix);		
		console.log ("nextIndex: " + xMatrix + " " + yMatrix);		
	} else {
		document.getElementById ("Resultado").innerHTML = "No puedo quitar más elementos.";
	}	
}

//Función para mostrar la matriz.
 function drawMatrix (elem, array){
 	elem.innerHTML = "";

 	var x=0;
 	var y=0;
 	while (x < xMatrix || y < yMatrix){
 		elem.innerHTML = elem.innerHTML + array[x][y] + " ";
 		x++;
 		if (x === array.length){
 			x=0;
 			y++;
 			elem.innerHTML = elem.innerHTML + "<br/>";
 		}
 	}
 }

 