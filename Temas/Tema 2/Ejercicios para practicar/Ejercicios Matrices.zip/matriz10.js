 "use strict";

//Función que ejectua el ejercicio
 function excuteExercise (numN) {
 	var pmatriz = document.getElementById ("matriz"); 
 	var pordenada = document.getElementById ("ordenada"); 
 	pmatriz.innerHTML = "";
 	pordenada.innerHTML = "";
 	
 	//Instanciamos la matriz
 	var matrix = new Array (numN);
 	for (var i=0;i<numN;i++){
 		matrix[i]=[new Array (numN)];
 	}

 	//Obtenemos una matriz de forma aleatoria
 	getRandomMatrix (matrix,numN);
 	drawMatrix (pmatriz, matrix); 	

 	//Ordenamos matriz
 	sortMatrix (matrix);
 	drawMatrix (pordenada, matrix); 
 }

 //Función para mostrar la matriz.
 function drawMatrix (elem, matrix){
 	elem.innerHTML="";
 	for (let array of matrix) { //En array tendremos cada uno de los array que tenemos en matrix
 		for (let value of array) { //En value obtenemos cada valor de los arrays internos.
 			elem.innerHTML = elem.innerHTML + value + " ";
 		}
 		elem.innerHTML = elem.innerHTML + "<br/>";
 	}
 }


//Función que rellena la matriz con números aleatorios
  function getRandomMatrix (matrix,num) {
 	var max = 99;
 	var min = 0;
 	for (let i=0,j; i<num; i++){
 		for (j=0;j<num;j++){
 			matrix[i][j] = Math.floor(Math.random()*(max-min+1)+min);
 		} 		
 	}
 }


 function sortMatrix (matrix){
 	//Índices temporales
 	var x = 0;
 	var y = 0;

 	//Índices del último elemento ordenado
 	var xMatrix = 0;
 	var yMatrix = 0;
 	var tmp; //Intercambiador

 	console.log ("Index: " + xMatrix + " " + yMatrix);
 	//Recorremos la matriz hasta el último de sus elementos
 	while (!(yMatrix === matrix.length-1 && xMatrix === matrix.length-1)){
 		//En función del último elemento ordenado, inicializamos los índices temporales.
		if (xMatrix === matrix.length-1){
			x = 0;
			y = yMatrix + 1;
		} else {
			x = xMatrix + 1;
			y = yMatrix;
		}

		console.log ("Outside: " + xMatrix + " " + yMatrix);
		
		//Recorremos la matriz en función de los índices temporales para realizar las comparaciones.
	 	while (!(y === matrix.length && x === 0)){

	 		console.log ("Inside: " + x + " " + y);
	 		//Se realiza el intercambio comparando los valores de ambos tipos de índices si el orden no es el correcto.
	 		if (matrix[xMatrix][yMatrix] > matrix[x][y]){
	 			tmp = matrix[xMatrix][yMatrix];
	 			matrix[xMatrix][yMatrix] = matrix[x][y];
	 			matrix[x][y] = tmp;
	 		}

	 		//Calculamos el siguiente índice temporal para seguir comparando.
 			if (x === matrix.length-1){
 				x = 0;
 				y = y + 1;
 			} else {
 				x = x + 1;
 			}

	 	}
	 	//Actualizamos índices ordenados para trabajar con el siguiente elemento.
		if (xMatrix === matrix.length-1){
			xMatrix = 0;
			yMatrix = yMatrix + 1;
		} else {
			xMatrix = xMatrix + 1;
			yMatrix = yMatrix;
		}	 	
 	} 		

 }