 "use strict";

 function execExercise (num) {
 	var pmatriz = document.getElementById ("matriz"); 
 	var pVectorA = document.getElementById ("VectorA"); 
 	var pVectorB = document.getElementById ("VectorB"); 
 	var matrix=[];
 	var vector = []; 
 	vector[0] = new Array (num);
 	vector[1] = new Array (num);

 	for (let i=0;i<num;i++){ //Instaciamos la matriz con arrays
 		matrix[i]=[new Array (num)];
 	}

 	getRandom (matrix,num);
 	drawMatrix (pmatriz, matrix);

 	for (let x=0,y, sumaA=0, sumaB=0;x<matrix.length;x++){ 		
 		for (y=0;y<matrix[x].length;y++){
 			sumaA = sumaA + matrix[x][y]; //Suma vertical
 			sumaB = sumaB + matrix[y][x]; //Suma horizontal
 		}
 		vector[0][x]=sumaA;
 		vector[1][x]=sumaB;
 		sumaA=0;
 		sumaB=0;
 	} 	

 	drawMatrix (pVectorA, vector); 	
 }

 //Función para mostrar la matriz.
 function drawMatrix (elem, matrix){
 	elem.innerHTML="";
 	for (let array of matrix) { //En array tendremos cada uno de los array que tenemos en matrix
 		for (let value of array) { //En value obtenemos cada valor de los arrays internos.
 			elem.innerHTML = elem.innerHTML + value + " ";
 		}
 		elem.innerHTML = elem.innerHTML + "<br/>";
 	}
 }

//Función que rellena la matriz con números aleatorios
  function getRandom (matrix,num) {
 	var max = 100;
 	var min = 0;
 	for (let i=0,j; i<num; i++){
 		for (j=0;j<num;j++){
 			matrix[i][j] = Math.floor(Math.random()*(max-min+1)+min);
 		} 		
 	}
 }
