 "use strict";

 function generateMatrix (num) { //num es un string, pero las operaciones lo transforman a entero automáticamnte.
 	var resultado = document.getElementById ("resultado"); 
 	var array = [];
 	for (let i=0;i<=num+1;i++){ //Instanciamos el número de arrays más 1 para la suma.
 		array[i]=[];
 	}

 	for (let i=0, x, y; i<num*num; i++){
 		y = i % num; //La fila se obtiene a partir del módulo del contador.
 		x = Math.floor(i / num); // La columna se obtiene dividiendo entre el número de columnas y redondeando a la baja
 		array[x][y] = i+1; //Como la i comienza en 0 le sumamos 1 a la asignación.		
 	}

 	drawMatrix (resultado, array); 
 }

 //Función para mostrar la matriz.
 function drawMatrix (elem, matrix){
 	elem.innerHTML = "";
 	for (let array of matrix) { //En array tendremos cada uno de los array que tenemos en matrix
 		for (let value of array) { //En value obtenemos cada valor de los arrays internos.
 			elem.innerHTML = elem.innerHTML + value + " ";
 		}
 		elem.innerHTML = elem.innerHTML + "<br/>";
 	}
 }

 window.onload = validate;