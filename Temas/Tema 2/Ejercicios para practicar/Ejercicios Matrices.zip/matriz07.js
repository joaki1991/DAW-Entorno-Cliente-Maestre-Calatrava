 "use strict";

 function execExercise (numR,numS) {
 	var pmatriz = document.getElementById ("matriz"); 
 	var pbusqueda = document.getElementById ("mbusqueda"); 
 	var presultado = document.getElementById ("Resultado"); 
 	pmatriz.innerHTML = "";
 	pbusqueda.innerHTML = "";
 	presultado.innerHTML = "";
 	
 	//Instanciación de ambas matrices
 	var matrix = new Array (numR);
 	var target = new Array (numS);
 	for (let i=0;i<numR;i++){
 		matrix[i]=[new Array (numR)];
 	}
 	for (let i=0;i<numS;i++){
 		target[i]=[new Array (numS)];
 	}

 	getRandomMatrix (matrix,numR,numR);
 	getRandomMatrix (target,numS,numS);
 	
 	drawMatrix (pmatriz, matrix);
 	drawMatrix (pbusqueda, target);

 	presultado.innerHTML = "La matriz de búsqueda está en la matriz: " + search (matrix, target);

 }

 //Función para mostrar la matriz.
 function drawMatrix (elem, matrix){
 	elem.innerHTML="";
 	for (let array of matrix) { //En array tendremos cada uno de los array que tenemos en matrix
 		for (let value of array) { //En value obtenemos cada valor de los arrays internos.
 			elem.innerHTML = elem.innerHTML + value + " ";
 		}
 		elem.innerHTML = elem.innerHTML + "<br/>";
 	}
 }

//Función que rellena la matriz con números aleatorios
  function getRandomMatrix (matrix,numM, numN) {
 	var max = 2;
 	var min = 0;
 	for (let i=0,j; i<numM; i++){
 		for (j=0;j<numN;j++){
 			matrix[i][j] = Math.floor(Math.random()*(max-min+1)+min);
 		} 		
 	}
 }

 function search (matrix, target){
 	var xMatrix = 0;
 	var yMatrix = 0;
 	var xTarget = 0;
 	var yTarget = 0;
 	var isMatrix = false;
 	var isTarget = true;

 	while (xMatrix < matrix.length-target.length+1 && isMatrix === false){ //Recorremos el eje x de la matriz principal mientras que la secundaria todavía tenga espacio.	
 		yMatrix = 0;	
 		while (yMatrix < matrix.length-target.length+1 && isMatrix === false){ //Recorremos el eje y de la matriz principal mientras que la secundaria todavía tenga espacio.	

 			xTarget = 0;
 			yTarget = 0; 		
 			console.log ("Inicio: " + xMatrix + " " + yMatrix);	
 			while (xTarget < target.length && isTarget === true){ //Recorremos la matriz secundaria para compararla con la principal
 				yTarget = 0;
 				while (yTarget < target.length && isTarget === true){
 					console.log ("Target: " + xTarget + " " + yTarget);	

 					//Comparamos ambas matrices
			 		if (matrix[xMatrix + xTarget][yMatrix + yTarget] !== target[xTarget][yTarget]){
			 			isTarget = false; //Si los valores no son iguales no continuamos buscando.
			 		} else {			 			
			 			yTarget++; //Actualizamos los índices para seguir buscando.
			 		}			
 				}
 				xTarget++; 				
 			} 		
	 		if (isTarget === true){ //Si salimos del bucle con valor true, es que la matriz secundaria está en la principal
	 			isMatrix = true; //Salimos de los bucles.
	 		} else { 			
	 			yMatrix++;
	 			isTarget = true;
	 		}
	 	} 
 		xMatrix++; 			
 	}

 	return isMatrix;
 }