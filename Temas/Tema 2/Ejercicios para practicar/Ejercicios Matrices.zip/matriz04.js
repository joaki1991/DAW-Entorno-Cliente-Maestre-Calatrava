 "use strict";

 function execExercise (num) {
 	var pmatriz = document.getElementById ("matriz"); 
 	var ptraspuesta = document.getElementById ("traspuesta"); 
 	var matrix=[];

 	for (let i=0;i<num;i++){ //Se genera la matriz con la instanciación de los arrays internos
 		matrix[i]=[new Array (num)];
 	}

 	getRandom (matrix,num);
 	drawMatrix (pmatriz, matrix);

 	transposition (matrix);
 	drawMatrix (ptraspuesta, matrix);
 }

 //Función para mostrar la matriz.
 function drawMatrix (elem, matrix){
 	elem.innerHTML="";
 	for (let array of matrix) { //En array tendremos cada uno de los array que tenemos en matrix
 		for (let value of array) { //En value obtenemos cada valor de los arrays internos.
 			elem.innerHTML = elem.innerHTML + value + " ";
 		}
 		elem.innerHTML = elem.innerHTML + "<br/>";
 	}
 }

//Función que rellena la matriz con números aleatorios
  function getRandom (matrix,num) {
 	var max = 100;
 	var min = 0;
 	for (let i=0,j; i<num; i++){
 		for (j=0;j<num;j++){
 			matrix[i][j] = Math.floor(Math.random()*(max-min+1)+min);
 		} 		
 	}
 }

//Función que genera la traspuesta.
 function transposition(matrix){
 	for (let i=0,j,tmp; i<matrix.length; i++){ //Recorremos todos los índices
 		for (j=0+i;j<matrix.length;j++){ //Recorremos los índices a partir de la i, ya que los anterios ya están transpuestos.
 			tmp = matrix[j][i];
 			matrix[j][i] = matrix[i][j];
 			matrix[i][j] = tmp;
 		} 		
 	} 	
 }